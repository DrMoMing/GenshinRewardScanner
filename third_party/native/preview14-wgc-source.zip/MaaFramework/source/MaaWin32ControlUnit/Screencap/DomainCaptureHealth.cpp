#include "DomainCaptureHealth.h"
#include <atomic>
#ifdef DOMAIN_CAPTURE_TEST_HOOKS
#include <chrono>
#include <thread>
namespace { std::atomic<int> fault_ { 0 }; }
extern "C" __declspec(dllexport) void __cdecl DomainScannerSetCaptureFault(int fault) { fault_.store(fault); }
bool DomainCaptureFaultPoint()
{
    if (fault_.load() == 2) {
        for (;;) { std::this_thread::sleep_for(std::chrono::milliseconds(100)); }
    }
    return fault_.load() == 1;
}
#endif

namespace {
std::atomic<DomainCaptureObserver> observer_ { nullptr };
}
extern "C" __declspec(dllexport) void __cdecl DomainScannerSetCaptureObserver(DomainCaptureObserver observer)
{
    observer_.store(observer, std::memory_order_release);
}
void DomainCaptureProgress(int stage, std::int64_t frame_time) noexcept
{
    if (auto callback = observer_.load(std::memory_order_acquire)) {
        callback(stage, frame_time);
    }
}

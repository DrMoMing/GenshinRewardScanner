#include "DomainCaptureHealth.h"
#include <atomic>
#include <windows.h>
#include <fstream>
#include <filesystem>
#include <iomanip>
namespace { std::atomic<long long> stamps[64]{}; long long stamp(){LARGE_INTEGER v; QueryPerformanceCounter(&v);return v.QuadPart;} }
extern "C" __declspec(dllexport) int __cdecl DomainScannerCopyTrace(long long* out, int count){if(count<64)return 0;for(int i=0;i<64;++i)out[i]=stamps[i].load();return 64;}



namespace {
std::atomic<DomainCaptureObserver> observer_ { nullptr };
}
extern "C" __declspec(dllexport) void __cdecl DomainScannerSetCaptureObserver(DomainCaptureObserver observer)
{
    observer_.store(observer, std::memory_order_release);
}
// Private experiment only. Capture records native QPC timestamps without
// entering Python; the reader copies a bounded ring after the capture finishes.
namespace {
struct TraceEntry { long long sequence,stage,tick,frame_time,thread; };
SRWLOCK trace_lock = SRWLOCK_INIT;
TraceEntry trace_ring[128]{};
long long trace_sequence=0;
std::atomic<long long> trace_signals{0},trace_last_signal{0};
void record_native_trace(int stage,std::int64_t frame_time) noexcept
{
    const auto now=stamp();
    if(stage==10){trace_last_signal.store(now);trace_signals.fetch_add(1);return;}
    AcquireSRWLockExclusive(&trace_lock);
    const auto sequence=++trace_sequence;
    trace_ring[(sequence-1)%128]={sequence,stage,now,frame_time,GetCurrentThreadId()};
    ReleaseSRWLockExclusive(&trace_lock);
}
}
extern "C" __declspec(dllexport) int __cdecl DomainScannerReadCaptureTrace(
    long long after,long long* values,int capacity,long long* metadata)
{
    if(!values||!metadata||capacity<1)return -1;
    LARGE_INTEGER frequency;QueryPerformanceFrequency(&frequency);
    AcquireSRWLockShared(&trace_lock);
    metadata[0]=1;metadata[1]=frequency.QuadPart;metadata[2]=trace_sequence;
    metadata[3]=trace_signals.load();metadata[4]=trace_last_signal.load();
    const auto first=(trace_sequence>128?trace_sequence-128:0)+1;
    auto begin=after+1;if(begin<first)begin=first;
    int count=0;
    for(auto seq=begin;seq<=trace_sequence&&count<capacity;++seq){
        const auto& item=trace_ring[(seq-1)%128];
        values[count*5]=item.sequence;values[count*5+1]=item.stage;
        values[count*5+2]=item.tick;values[count*5+3]=item.frame_time;
        values[count*5+4]=item.thread;++count;
    }
    ReleaseSRWLockShared(&trace_lock);
    return count;
}


void DomainCaptureResetDevices() noexcept;
namespace {
std::atomic<bool> detailed{false};
std::atomic<long long> thread_stamps[64]{};
long long cpu_tick(){FILETIME a,b,k,u;if(!GetThreadTimes(GetCurrentThread(),&a,&b,&k,&u))return 0;
 ULARGE_INTEGER x,y;x.LowPart=k.dwLowDateTime;x.HighPart=k.dwHighDateTime;
 y.LowPart=u.dwLowDateTime;y.HighPart=u.dwHighDateTime;return x.QuadPart+y.QuadPart;}
}
extern "C" __declspec(dllexport) void __cdecl DomainScannerSetDetailedMonitoring(int value){detailed.store(value!=0);}
extern "C" __declspec(dllexport) int __cdecl DomainScannerReadCpuTrace(long long* out,int count){
 if(count<64)return 0;for(int i=0;i<64;++i)out[i]=thread_stamps[i].load();return 64;}

void DomainCaptureProgress(int stage, std::int64_t frame_time) noexcept
{
    const bool full=detailed.load(std::memory_order_relaxed);
    if(stage==1)DomainCaptureResetDevices();
    if(stage>=11&&!full)return;
    record_native_trace(stage,frame_time);
    if(full&&stage>=0&&stage<32&&stage!=10)thread_stamps[stage*2].store(cpu_tick());
    if(stage>=0&&stage<32&&stage!=10)stamps[stage*2].store(stamp());
    if (auto callback = observer_.load(std::memory_order_acquire)) {
        if(stage<11)callback(stage, frame_time);
    }
    if(stage>=0&&stage<32&&stage!=10)stamps[stage*2+1].store(stamp());
    if(full&&stage>=0&&stage<32&&stage!=10)thread_stamps[stage*2+1].store(cpu_tick());
}

#include <d3d11.h>
// Diagnostic-only adapter identity, sampled once after successful texture init.
// This snapshot is outside the hot Map interval and does not change its device.
#include <dxgi.h>
namespace { std::atomic<long long> capture_devices[8]{}; }
void DomainCaptureRecordDevices(ID3D11Device* capture,ID3D11Texture2D* texture) noexcept {
 if(!detailed.load()||capture_devices[7].load())return;
 auto adapter_id=[](ID3D11Device* device,long long* values){
  IDXGIDevice* dxgi=nullptr;IDXGIAdapter* adapter=nullptr;DXGI_ADAPTER_DESC desc{};
  HRESULT hr=device->QueryInterface(__uuidof(IDXGIDevice),reinterpret_cast<void**>(&dxgi));
  if(SUCCEEDED(hr))hr=dxgi->GetAdapter(&adapter);
  if(SUCCEEDED(hr))hr=adapter->GetDesc(&desc);
  values[0]=desc.AdapterLuid.HighPart;values[1]=desc.AdapterLuid.LowPart;values[2]=hr;
  if(adapter)adapter->Release();if(dxgi)dxgi->Release();
 };
 long long values[8]{};ID3D11Device* source=nullptr;texture->GetDevice(&source);
 adapter_id(capture,values);if(source){adapter_id(source,values+3);source->Release();}
 D3D11_TEXTURE2D_DESC desc{};texture->GetDesc(&desc);values[6]=desc.Format;values[7]=1;
 for(int i=0;i<8;++i)capture_devices[i].store(values[i]);
}
extern "C" __declspec(dllexport) int __cdecl DomainScannerReadDeviceMetadata(long long* out,int count){
 if(count<8)return 0;for(int i=0;i<8;++i)out[i]=capture_devices[i].load();return 8;
}

void DomainCaptureResetDevices() noexcept {capture_devices[7].store(0);}

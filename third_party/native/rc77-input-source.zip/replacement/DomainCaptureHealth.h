#pragma once
#include <cstdint>

// Private, additive DomainScanner hook. No change to existing Maa ABI.
// 1 init, 2 waiting, 3 frame received, 4 readback, 5 complete,
// 6 no-frame timeout, 7 session released, 8 ScreenDC acquire,
// 10 producer FrameArrived signal (not consumer work progress).
using DomainCaptureObserver = void(__cdecl*)(int, std::int64_t);
extern "C" __declspec(dllexport) void __cdecl DomainScannerSetCaptureObserver(DomainCaptureObserver observer);
void DomainCaptureProgress(int stage, std::int64_t frame_time = 0) noexcept;
#ifdef DOMAIN_CAPTURE_TEST_HOOKS
extern "C" __declspec(dllexport) void __cdecl DomainScannerSetCaptureFault(int fault);
bool DomainCaptureFaultPoint();
#else
inline bool DomainCaptureFaultPoint() { return false; }
#endif

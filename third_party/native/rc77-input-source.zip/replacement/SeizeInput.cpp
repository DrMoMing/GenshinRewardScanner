#include "SeizeInput.h"

#include "MaaUtils/Encoding.h"
#include "MaaUtils/Logger.h"
#include "MaaUtils/Platform.h"
#include "MaaUtils/SafeWindows.hpp"

#include "InputUtils.h"

MAA_CTRL_UNIT_NS_BEGIN

SeizeInput::~SeizeInput()
{
    unblock_input();
}

void SeizeInput::ensure_foreground()
{
    ::MaaNS::CtrlUnitNs::ensure_foreground_and_topmost(hwnd_);
}

std::pair<int, int> SeizeInput::get_target_pos() const
{
    if (last_pos_set_) {
        return last_pos_;
    }

    // 未设置时返回窗口客户区中心
    RECT rect = { };
    if (hwnd_ && GetClientRect(hwnd_, &rect)) {
        return { (rect.right - rect.left) / 2, (rect.bottom - rect.top) / 2 };
    }
    return { 0, 0 };
}

MaaControllerFeature SeizeInput::get_features() const
{
    return MaaControllerFeature_UseMouseDownAndUpInsteadOfClick | MaaControllerFeature_UseKeyboardDownAndUpInsteadOfClick;
}

// get_features() 返回 MaaControllerFeature_UseMouseDownAndUpInsteadOfClick，
// 上层 ControllerAgent 会使用 touch_down/touch_up 替代 click/swipe
bool SeizeInput::click(int x, int y)
{
    LogError << "deprecated: get_features() returns MaaControllerFeature_UseMouseDownAndUpInsteadOfClick, "
                "use touch_down/touch_up instead"
             << VAR(x) << VAR(y);
    return false;
}

bool SeizeInput::swipe(int x1, int y1, int x2, int y2, int duration)
{
    LogError << "deprecated: get_features() returns MaaControllerFeature_UseMouseDownAndUpInsteadOfClick, "
                "use touch_down/touch_move/touch_up instead"
             << VAR(x1) << VAR(y1) << VAR(x2) << VAR(y2) << VAR(duration);
    return false;
}

bool SeizeInput::touch_down(int contact, int x, int y, int pressure)
{
    POINT point = { x, y };

    if (hwnd_) {
        ensure_foreground();
        ClientToScreen(hwnd_, &point);
    }
    LogInfo << VAR(contact) << VAR(x) << VAR(y) << VAR(pressure) << VAR(point.x) << VAR(point.y) << VAR_VOIDP(hwnd_);

    check_and_block_input();

    SetCursorPos(point.x, point.y);

    INPUT input = { };
    input.type = INPUT_MOUSE;

    MouseEventFlags flags_info;
    if (!contact_to_mouse_down_flags(contact, flags_info)) {
        LogError << "contact out of range" << VAR(contact);
        return false;
    }

    input.mi.dwFlags = flags_info.flags;
    input.mi.mouseData = flags_info.button_data;

    SendInput(1, &input, sizeof(INPUT));

    last_pos_ = { x, y };
    last_pos_set_ = true;

    return true;
}

bool SeizeInput::touch_move(int contact, int x, int y, int pressure)
{
    std::ignore = contact;
    std::ignore = pressure;

    POINT point = { x, y };

    if (hwnd_) {
        ensure_foreground();
        ClientToScreen(hwnd_, &point);
    }
    // LogInfo << VAR(contact) << VAR(x) << VAR(y) << VAR(pressure) << VAR(point.x) << VAR(point.y) << VAR_VOIDP(hwnd_);

    // 使用 SendInput + MOUSEEVENTF_MOVE + MOUSEEVENTF_ABSOLUTE 移动光标
    // 需要将屏幕坐标转换为 0-65535 范围的归一化坐标
    int screen_width = GetSystemMetrics(SM_CXSCREEN);
    int screen_height = GetSystemMetrics(SM_CYSCREEN);
    if (screen_width <= 0 || screen_height <= 0) {
        LogError << "GetSystemMetrics returned invalid screen size" << VAR(screen_width) << VAR(screen_height);
        return false;
    }

    INPUT input = { };
    input.type = INPUT_MOUSE;
    input.mi.dx = static_cast<LONG>((point.x * 65535) / screen_width);
    input.mi.dy = static_cast<LONG>((point.y * 65535) / screen_height);
    input.mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE;

    SendInput(1, &input, sizeof(INPUT));

    last_pos_ = { x, y };
    last_pos_set_ = true;

    return true;
}

bool SeizeInput::touch_up(int contact)
{
    if (hwnd_) {
        ensure_foreground();
    }
    LogInfo << VAR(contact) << VAR(hwnd_);

    OnScopeLeave([this]() { unblock_input(); });

    INPUT input = { };
    input.type = INPUT_MOUSE;

    MouseEventFlags flags_info;
    if (!contact_to_mouse_up_flags(contact, flags_info)) {
        LogError << "contact out of range" << VAR(contact);
        return false;
    }

    input.mi.dwFlags = flags_info.flags;
    input.mi.mouseData = flags_info.button_data;

    SendInput(1, &input, sizeof(INPUT));

    return true;
}

bool SeizeInput::relative_move(int dx, int dy)
{
    if (dx == 0 && dy == 0) {
        return true;
    }

    if (hwnd_) {
        ensure_foreground();
    }

    LogInfo << VAR(dx) << VAR(dy) << VAR_VOIDP(hwnd_);

    check_and_block_input();

    OnScopeLeave([this]() { unblock_input(); });

    INPUT input = { };
    input.type = INPUT_MOUSE;
    input.mi.dx = dx;
    input.mi.dy = dy;
    input.mi.dwFlags = MOUSEEVENTF_MOVE;

    return SendInput(1, &input, sizeof(INPUT)) == 1;
}

// get_features() 返回 MaaControllerFeature_UseKeyboardDownAndUpInsteadOfClick，
// 上层 ControllerAgent 会使用 key_down/key_up 替代 click_key
bool SeizeInput::click_key(int key)
{
    LogError << "deprecated: get_features() returns MaaControllerFeature_UseKeyboardDownAndUpInsteadOfClick, "
                "use key_down/key_up instead"
             << VAR(key);
    return false;
}

bool SeizeInput::input_text(const std::string& text)
{
    if (hwnd_) {
        ensure_foreground();
    }

    auto u16_text = to_u16(text);
    LogInfo << VAR(text) << VAR(u16_text) << VAR(hwnd_);

    // check_and_block_input();

    // OnScopeLeave([this]() { unblock_input(); });

    std::vector<INPUT> input_vec;

    for (const auto ch : u16_text) {
        INPUT input = { };
        input.type = INPUT_KEYBOARD;
        input.ki.dwFlags = KEYEVENTF_UNICODE;
        input.ki.wScan = ch;

        input_vec.emplace_back(input);

        input.ki.dwFlags |= KEYEVENTF_KEYUP;

        input_vec.emplace_back(input);
    }

    UINT written = SendInput(static_cast<UINT>(input_vec.size()), input_vec.data(), sizeof(INPUT));

    if (written != input_vec.size()) {
        LogError << VAR(written) << VAR(input_vec.size()) << VAR(u16_text.size());
        return false;
    }
    return true;
}

bool SeizeInput::key_down(int key)
{
    if (hwnd_) {
        ensure_foreground();
    }
    LogInfo << VAR(key) << VAR(hwnd_);

    // check_and_block_input();

    INPUT inputs[1] = { };

    inputs[0].type = INPUT_KEYBOARD;
    inputs[0].ki.wVk = static_cast<WORD>(key);
    inputs[0].ki.wScan = static_cast<WORD>(MapVirtualKeyW(static_cast<UINT>(key), MAPVK_VK_TO_VSC));

    SendInput(ARRAYSIZE(inputs), inputs, sizeof(INPUT));

    return true;
}

bool SeizeInput::key_up(int key)
{
    if (hwnd_) {
        ensure_foreground();
    }
    LogInfo << VAR(key) << VAR(hwnd_);

    // OnScopeLeave([this]() { unblock_input(); });

    INPUT inputs[1] = { };

    inputs[0].type = INPUT_KEYBOARD;
    inputs[0].ki.wVk = static_cast<WORD>(key);
    inputs[0].ki.wScan = static_cast<WORD>(MapVirtualKeyW(static_cast<UINT>(key), MAPVK_VK_TO_VSC));
    inputs[0].ki.dwFlags = KEYEVENTF_KEYUP;

    SendInput(ARRAYSIZE(inputs), inputs, sizeof(INPUT));

    return true;
}

bool SeizeInput::scroll(int dx, int dy)
{
    LogInfo << VAR(dx) << VAR(dy);

    if (hwnd_) {
        ensure_foreground();
    }

    check_and_block_input();

    OnScopeLeave([this]() { unblock_input(); });

    // 移动光标到目标位置
    auto [target_x, target_y] = get_target_pos();
    POINT point = { target_x, target_y };
    if (hwnd_) {
        ClientToScreen(hwnd_, &point);
    }
    SetCursorPos(point.x, point.y);

    INPUT input = { };
    input.type = INPUT_MOUSE;

    if (dy != 0) {
        input.mi.dwFlags = MOUSEEVENTF_WHEEL;
        input.mi.mouseData = static_cast<DWORD>(dy);
        SendInput(1, &input, sizeof(INPUT));
    }

    if (dx != 0) {
        input.mi.dwFlags = MOUSEEVENTF_HWHEEL;
        input.mi.mouseData = static_cast<DWORD>(dx);
        SendInput(1, &input, sizeof(INPUT));
    }

    return true;
}

void SeizeInput::check_and_block_input()
{
    if (!block_input_) {
        return;
    }
    BlockInput(TRUE);
}

void SeizeInput::unblock_input()
{
    if (!block_input_) {
        return;
    }
    BlockInput(FALSE);
}

void SeizeInput::inactive()
{
    LogFunc;

    unblock_input();

    if (hwnd_) {
        // HWND_NOTOPMOST has no effect for an already non-topmost window.
        // Avoid its cross-thread window-message synchronization in that case.
        // On query failure preserve the original cleanup; do not guess state.
        SetLastError(ERROR_SUCCESS);
        const auto style = GetWindowLongPtrW(hwnd_, GWL_EXSTYLE);
        const bool query_failed = style == 0 && GetLastError() != ERROR_SUCCESS;
        if (query_failed || (style & WS_EX_TOPMOST)) {
            SetWindowPos(hwnd_, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        }
    }
}

MAA_CTRL_UNIT_NS_END

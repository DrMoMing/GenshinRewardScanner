@echo off
cd /d "%~dp0..\..\.."
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
MSBuild portable\native\input-idle\MaaWin32ControlUnit.vcxproj /p:Configuration=Release /p:Platform=x64 /m:2 /v:minimal /nologo
exit /b %errorlevel%

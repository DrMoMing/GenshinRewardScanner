"""Keep RC69 capture; omit only already-non-topmost inactive maintenance."""
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path.cwd();BASE=ROOT/'portable/native/frame-size';OUT=ROOT/'portable/native/input-idle';OUT.mkdir(exist_ok=True)
for name in ('DomainCaptureHealth.cpp','FramePoolScreencap.cpp','FramePoolScreencap.h'):(OUT/name).write_bytes((BASE/name).read_bytes())
src=ROOT/'debug/rc49_native/MaaFramework/source/MaaWin32ControlUnit/Input'
code=(src/'SeizeInput.cpp').read_text(encoding='utf8')
old='''    if (hwnd_) {
        SetWindowPos(hwnd_, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    }'''
new='''    if (hwnd_) {
        // HWND_NOTOPMOST has no effect for an already non-topmost window.
        // Avoid its cross-thread window-message synchronization in that case.
        // On query failure preserve the original cleanup; do not guess state.
        SetLastError(ERROR_SUCCESS);
        const auto style = GetWindowLongPtrW(hwnd_, GWL_EXSTYLE);
        const bool query_failed = style == 0 && GetLastError() != ERROR_SUCCESS;
        if (query_failed || (style & WS_EX_TOPMOST)) {
            SetWindowPos(hwnd_, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        }
    }'''
assert code.count(old)==1
(OUT/'SeizeInput.cpp').write_text(code.replace(old,new),encoding='utf8');(OUT/'SeizeInput.h').write_bytes((src/'SeizeInput.h').read_bytes())
s=(BASE/'MaaWin32ControlUnit.vcxproj').read_text(encoding='utf8').replace(str(BASE),str(OUT))
s=s.replace(str(src/'SeizeInput.cpp'),str(OUT/'SeizeInput.cpp'))
s=s.replace('<AdditionalIncludeDirectories>','<AdditionalIncludeDirectories>'+str(src)+';')
(OUT/'MaaWin32ControlUnit.vcxproj').write_text(s,encoding='utf8')
(OUT/'build.cmd').write_text((BASE/'build.cmd').read_text().replace('native\\frame-size','native\\input-idle'))
(OUT/'.gitignore').write_text('bin/\nobj/\n')
print('Only SeizeInput::inactive differs; foreground, SendInput, capture unchanged')
